peso = float(input("Ingrese su peso en kg"))
altura = float(input("Ingrese su altura en metros"))
IMC = peso/altura**2
print(round(IMC,2))
