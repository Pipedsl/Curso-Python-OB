import pickle

class Vehiculo:
    ruedas = 0
    modelo = ""

    def __init__(self,ruedas,modelo):
        self.ruedas = ruedas
        self.modelo = modelo

    def getModelo(self):
        return self.modelo

#Guardar en un archivo

v1 = Vehiculo(4,"Audi TT")
f = open('datos.bin', 'wb') #guardar en datos.bin
pickle.dump(v1,f)
f.close()

#Cargar un archivo

f = open('datos.bin', 'rb')
audi = pickle.load(f)
f.close()

print(type(audi))
print(audi.getModelo(), " cantidad de ruedas: ", audi.ruedas)
