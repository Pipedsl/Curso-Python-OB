f=open('Ejercicio1InputOutput.txt', 'w')
f.close()

f=open('Ejercicio1InputOutput.txt', 'w')
f.write("Hola Mundo")
f.close()