import operaciones as op


print(op.suma(2,4))
print(op.resta(5,3))
print(op.multiplica(2,2))
print(op.divide(4,2))
