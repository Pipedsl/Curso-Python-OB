
def suma(a,b):
    return a + b

def resta(a,b):
    return a - b

def multiplica(a,b):
    return a * b

def divide(a,b):
    return a / b