lista = []

for i in range(1,101):
    lista.append(i)
    listaOrdenInverso = sorted(lista, reverse = True)

print(listaOrdenInverso)
